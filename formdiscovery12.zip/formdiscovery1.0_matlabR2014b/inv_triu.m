function x = inv_triu(U)
% INV_TRIU     Invert upper triangular matrix.

%x = solve_triu(U,eye(size(U)));
x = inv(U);